package org.generation.eScriptCoder.repository;

import org.generation.eScriptCoder.repository.entity.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Integer> {

}
